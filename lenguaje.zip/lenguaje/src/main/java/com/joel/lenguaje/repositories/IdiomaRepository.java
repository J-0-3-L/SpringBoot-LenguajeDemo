package com.joel.lenguaje.repositories;

import org.springframework.data.repository.CrudRepository;

import com.joel.lenguaje.models.Idioma;

public interface IdiomaRepository extends CrudRepository <Idioma,Long> {
    
}
